function startGeogebra() {
    var ggbApp = new GGBApplet(  {"appName": "classic", "width": 800, "height": 600, "showToolBar": true, "showAlgebraInput": false, "showMenuBar": true }, true);
    ggbApp.inject('ggb-element');
}
