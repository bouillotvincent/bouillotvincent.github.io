//Charge Geogebra au démarrage de la page :

//window.addEventListener("load", startGeogebra);
//var ggbApp = new GGBApplet(  {"appName": "classic", "width": 800, "height": 600, "showToolBar": true, "showAlgebraInput": false, "showMenuBar": true }, true);
//window.addEventListener("load", function() { ggbApp.inject('ggb-element'); });

function startGeogebra() {
// répond à un clic sur le bouton

}

