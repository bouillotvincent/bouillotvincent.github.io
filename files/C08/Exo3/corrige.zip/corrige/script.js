function modif() {
	document.querySelector("#para1").style.border="dotted blue 8px";
}

function foncRouge() {
	document.querySelector("#para3").classList.remove("vert","noir");
	document.querySelector("#para3").classList.add("rouge");
}

function foncNoir() {
	document.querySelector("#para3").classList.remove("rouge","vert");
	document.querySelector("#para3").classList.add("noir");
}

var nombreClick=0;
function modifMessage() {
    nombreClick = nombreClick + 1
	if (nombreClick%2 === 0) {    
		document.querySelector("#para4").innerHTML = "Bravo, vous avez cliqué "+nombreClick+" fois sur le bouton !";
	} 
	else { 
		document.querySelector("#para4").innerHTML = " Touche pas à ma Corona ";
	}
	//document.querySelector("#para4").innerHTML = "Bravo, vous avez cliqué " + nombreClick + " fois sur le bouton !";
}

function foncEntre(){
	document.querySelector("#maDiv").classList.remove("blanc");
	document.querySelector("#maDiv").classList.add("rouge2"); 
}
	
function foncQuitte() { 
	document.querySelector("#maDiv").classList.remove("rouge2"); 
	document.querySelector("#maDiv").classList.add("blanc");
}
	