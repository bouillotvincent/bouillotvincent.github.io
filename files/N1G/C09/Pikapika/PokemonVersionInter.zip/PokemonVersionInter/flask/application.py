from flask import Flask, render_template, request, make_response, redirect
import random
import datetime

app = Flask(__name__)

@app.route('/')  # renvoie la page d'accueil index.html
def index():
	return render_template("monPokemon.html")

def calculerVie(x):
	if x > 5:
		pVie = random.randint(101,150)
	else:
		pVie = random.randint(50,100)
	return pVie

def calculerForce(x):
	return int(x**2-4*x+8)

@app.route('/resultat', methods = ['POST','GET'])
def resultat():
	result = request.form
	print(result)
	pVie = calculerVie(len(result['nom']))
	pForce = calculerForce(len(result['surnom']))
	n = result['nom']     # l'entrée 'nom' du dictionnaire Python : 'Jaillet'
	p = result['surnom']  # l'entrée 'prénom' du dico Python : ['Enzo', 'Deyan']
	return render_template("resultat.html", pdv=pVie, pdf=pForce, nom=n, surnom=p)


# @app.route('/resultat',methods = ['GET'])
# def choucroute():
#   result=request.args  # récupération des arguments
#   n = result['nom']
#   p = result['prenom']
#   return render_template("resultat.html", nom=n, prenom=p)

app.run(debug=True)
