from flask import Flask, render_template, request, make_response, redirect
import random
import datetime

app = Flask(__name__)

@app.route('/')
def index():
	pseudo_visiteur = request.cookies.get('pseudo') # on récupère le cookie 'pseudo'
	if pseudo_visiteur is not None:
		return render_template("monPokemon.html", pseudo = pseudo_visiteur)
	else:
		return render_template("credentials.html")


@app.route('/setcookie',methods = ['POST','GET'])
def rerouting():
	if request.method == 'POST':
		print(request.form)
		result = request.form
		reponse = make_response(redirect('/'))
		reponse.set_cookie('pseudo', result['pseudo'], max_age=3600*24)
		return reponse
	else:
		return redirect('/')

def calculerVie(x):
	if x > 5:
		pVie = random.randint(101,150)
	else:
		pVie = random.randint(50,100)
	return pVie

def calculerForce(x):
	return int(x**2-4*x+8)

@app.route('/resultat', methods = ['POST','GET'])
def resultat():
	result = request.form
	print(result)
	pVie = calculerVie(len(result['nom']))
	pForce = calculerForce(len(result['surnom']))
	n = result['nom']     # l'entrée 'nom' du dictionnaire Python : 'Jaillet'
	p = result['surnom']  # l'entrée 'prénom' du dico Python : ['Enzo', 'Deyan']
	return render_template("resultat.html", pdv=pVie, pdf=pForce, nom=n, surnom=p)


app.run(debug=True)
