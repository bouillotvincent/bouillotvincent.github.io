function modif() {
	document.querySelector("#para1").style.border="dotted blue 8px";
}

function foncRouge() {
	document.querySelector("#para3").classList.remove("vert","noir");
	document.querySelector("#para3").classList.add("rouge");
}

function foncNoir() {
	document.querySelector("#para3").classList.remove("rouge","vert");
	document.querySelector("#para3").classList.add("noir");
}

var start = clicks = frequency = 0 // les variables doivent être globales (extérieures à la fonction)
function modifMessage() {
    if (start == 0) start = new Date   // on enregistre la nouvelle date
    ++clicks  // on fait clicks = clicks + 1
	document.querySelector("#para4").innerHTML = "Bravo, vous avez cliqué " + clicks + " fois sur le bouton !";
	if ((new Date - start)/1000>= 5) { // vérification du temps écoulé
		alert('CPS = '+ clicks/(new Date - start)*1000+ ' (en 5 secondes) !')   // affichage
		start = clicks = frequency = 0  // prêt à recommencer !
	}
}

function foncEntre(){
	document.querySelector("#maDiv").classList.remove("blanc");
	document.querySelector("#maDiv").classList.add("rouge2"); 
}
	
function foncQuitte() { 
	document.querySelector("#maDiv").classList.remove("rouge2"); 
	document.querySelector("#maDiv").classList.add("blanc");
}
	