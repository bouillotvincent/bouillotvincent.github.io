#!/bin/bash
a=0
rm Exercice3/*.jpg
while ((a <= 2222))
do
  printf -v suffix "%04d" "$a"
  cd Exercice3
  touch DSC_$suffix.jpg
  cd ..
  ((a += 1))
done
