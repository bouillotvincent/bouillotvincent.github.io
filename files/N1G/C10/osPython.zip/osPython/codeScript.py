# importer la bibliothèque os sur la ligne 2


# indiquer le répertoire dont vous souhaitez afficher le contenu
dir = "/bin/"

def readDirContent(repo):
    """ Cette fonction lit le contenu d'un dossier et renvoie le résultat sous forme de liste [fichier1, fichier2, fichier3]
    """
    return repo

def lsPython(repoList):
    """ Cette fonction prend une liste représentant le contenu d\'un dossier et l\'affiche comme un ls classique
    fichier1
    fichier2
    fichier3
    """
    return None


lsPython(readDirContent(dir))
