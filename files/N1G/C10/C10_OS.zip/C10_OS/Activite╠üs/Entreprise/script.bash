#!/bin/bash
a=1
while ((a <= 100)) 
do
  printf -v suffix "%04d" "$a"
  echo Employe$suffix   # Affiche dans le terminal NumeroXXXX -- Inspirez-vous pour créer votre arborescence.
  # Début partie à ajouter

  # Fin partie à ajouter
  ((a += 1))
done
